responsive ok {
    header
    hero section
    sommaire
    formulaire
    footer
}

responsive ko {
    section principale
}